﻿namespace CarCRM.Models
{
    public class Fornecedor : Pessoa
    {
        public int Id { get; set; }
        public string Documento { get; set; }
        public int FornecedorTipoId { get; set; }

        public FornecedorTipo FornecedorTipo { get; set; }
    }
}
