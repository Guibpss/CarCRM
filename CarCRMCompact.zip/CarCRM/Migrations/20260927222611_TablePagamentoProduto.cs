﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CarCRM.Migrations
{
    /// <inheritdoc />
    public partial class TablePagamentoProduto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Produtos_Clientes_ClienteId",
                table: "Produtos");

            migrationBuilder.DropForeignKey(
                name: "FK_Servicos_Clientes_ClienteId",
                table: "Servicos");

            migrationBuilder.DropIndex(
                name: "IX_Servicos_ClienteId",
                table: "Servicos");

            migrationBuilder.DropIndex(
                name: "IX_Produtos_ClienteId",
                table: "Produtos");

            migrationBuilder.DropColumn(
                name: "ConfirmaSenha",
                table: "Usuarios");

            migrationBuilder.DropColumn(
                name: "ClienteId",
                table: "Servicos");

            migrationBuilder.RenameColumn(
                name: "ClienteId",
                table: "Produtos",
                newName: "Quantidade");

            migrationBuilder.AddColumn<int>(
                name: "ProdutoTipoId",
                table: "Produtos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CompraProdutoId",
                table: "Pagamentos",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "VendaProdutoId",
                table: "Pagamentos",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Documento",
                table: "Fornecedores",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "CompraProdutos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataCompra = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ValorCompra = table.Column<float>(type: "real", nullable: false),
                    Desconto = table.Column<float>(type: "real", nullable: false),
                    FornecedorId = table.Column<int>(type: "int", nullable: false),
                    StatusCompraId = table.Column<int>(type: "int", nullable: false),
                    CriadoEm = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Excluido = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompraProdutos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CompraProdutos_Fornecedores_FornecedorId",
                        column: x => x.FornecedorId,
                        principalTable: "Fornecedores",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CompraProdutos_StatusCompras_StatusCompraId",
                        column: x => x.StatusCompraId,
                        principalTable: "StatusCompras",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProdutoTipos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProdutoTipos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "VendaProdutos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DataVenda = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ValorVenda = table.Column<float>(type: "real", nullable: false),
                    Desconto = table.Column<float>(type: "real", nullable: false),
                    ClienteId = table.Column<int>(type: "int", nullable: false),
                    StatusVendaId = table.Column<int>(type: "int", nullable: false),
                    CriadoEm = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Excluido = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VendaProdutos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_VendaProdutos_Clientes_ClienteId",
                        column: x => x.ClienteId,
                        principalTable: "Clientes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VendaProdutos_StatusVendas_StatusVendaId",
                        column: x => x.StatusVendaId,
                        principalTable: "StatusVendas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PagamentoCompraProdutos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CompraProdutoId = table.Column<int>(type: "int", nullable: false),
                    PagamentoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PagamentoCompraProdutos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PagamentoCompraProdutos_CompraProdutos_CompraProdutoId",
                        column: x => x.CompraProdutoId,
                        principalTable: "CompraProdutos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PagamentoCompraProdutos_Pagamentos_PagamentoId",
                        column: x => x.PagamentoId,
                        principalTable: "Pagamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PagamentoVendaProdutos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VendaProdutoId = table.Column<int>(type: "int", nullable: false),
                    PagamentoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PagamentoVendaProdutos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PagamentoVendaProdutos_Pagamentos_PagamentoId",
                        column: x => x.PagamentoId,
                        principalTable: "Pagamentos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PagamentoVendaProdutos_VendaProdutos_VendaProdutoId",
                        column: x => x.VendaProdutoId,
                        principalTable: "VendaProdutos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Produtos_ProdutoTipoId",
                table: "Produtos",
                column: "ProdutoTipoId");

            migrationBuilder.CreateIndex(
                name: "IX_Pagamentos_CompraProdutoId",
                table: "Pagamentos",
                column: "CompraProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_Pagamentos_VendaProdutoId",
                table: "Pagamentos",
                column: "VendaProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_CompraProdutos_FornecedorId",
                table: "CompraProdutos",
                column: "FornecedorId");

            migrationBuilder.CreateIndex(
                name: "IX_CompraProdutos_StatusCompraId",
                table: "CompraProdutos",
                column: "StatusCompraId");

            migrationBuilder.CreateIndex(
                name: "IX_PagamentoCompraProdutos_CompraProdutoId",
                table: "PagamentoCompraProdutos",
                column: "CompraProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_PagamentoCompraProdutos_PagamentoId",
                table: "PagamentoCompraProdutos",
                column: "PagamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_PagamentoVendaProdutos_PagamentoId",
                table: "PagamentoVendaProdutos",
                column: "PagamentoId");

            migrationBuilder.CreateIndex(
                name: "IX_PagamentoVendaProdutos_VendaProdutoId",
                table: "PagamentoVendaProdutos",
                column: "VendaProdutoId");

            migrationBuilder.CreateIndex(
                name: "IX_VendaProdutos_ClienteId",
                table: "VendaProdutos",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_VendaProdutos_StatusVendaId",
                table: "VendaProdutos",
                column: "StatusVendaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Pagamentos_CompraProdutos_CompraProdutoId",
                table: "Pagamentos",
                column: "CompraProdutoId",
                principalTable: "CompraProdutos",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Pagamentos_VendaProdutos_VendaProdutoId",
                table: "Pagamentos",
                column: "VendaProdutoId",
                principalTable: "VendaProdutos",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Produtos_ProdutoTipos_ProdutoTipoId",
                table: "Produtos",
                column: "ProdutoTipoId",
                principalTable: "ProdutoTipos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Pagamentos_CompraProdutos_CompraProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Pagamentos_VendaProdutos_VendaProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropForeignKey(
                name: "FK_Produtos_ProdutoTipos_ProdutoTipoId",
                table: "Produtos");

            migrationBuilder.DropTable(
                name: "PagamentoCompraProdutos");

            migrationBuilder.DropTable(
                name: "PagamentoVendaProdutos");

            migrationBuilder.DropTable(
                name: "ProdutoTipos");

            migrationBuilder.DropTable(
                name: "CompraProdutos");

            migrationBuilder.DropTable(
                name: "VendaProdutos");

            migrationBuilder.DropIndex(
                name: "IX_Produtos_ProdutoTipoId",
                table: "Produtos");

            migrationBuilder.DropIndex(
                name: "IX_Pagamentos_CompraProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropIndex(
                name: "IX_Pagamentos_VendaProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropColumn(
                name: "ProdutoTipoId",
                table: "Produtos");

            migrationBuilder.DropColumn(
                name: "CompraProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropColumn(
                name: "VendaProdutoId",
                table: "Pagamentos");

            migrationBuilder.DropColumn(
                name: "Documento",
                table: "Fornecedores");

            migrationBuilder.RenameColumn(
                name: "Quantidade",
                table: "Produtos",
                newName: "ClienteId");

            migrationBuilder.AddColumn<string>(
                name: "ConfirmaSenha",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "ClienteId",
                table: "Servicos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Servicos_ClienteId",
                table: "Servicos",
                column: "ClienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Produtos_ClienteId",
                table: "Produtos",
                column: "ClienteId");

            migrationBuilder.AddForeignKey(
                name: "FK_Produtos_Clientes_ClienteId",
                table: "Produtos",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Servicos_Clientes_ClienteId",
                table: "Servicos",
                column: "ClienteId",
                principalTable: "Clientes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
