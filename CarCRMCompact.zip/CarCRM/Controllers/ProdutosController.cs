﻿using CarCRM.Data;
using CarCRM.Models;
using CarCRM.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NuGet.Protocol;


public class ProdutosController : Controller
{
    private readonly CarCRMContext _context;

    public ProdutosController(CarCRMContext context)
    {
        _context = context;
    }


    public async Task<IActionResult> Index()
    {
        var produtos = await _context.Produtos
            .Include(p => p.ProdutoTipo)
            .ToListAsync();

        var produtosViewModel = produtos.Select(p => new ProdutoViewModel
        {
            Id = p.Id,
            Nome = p.Nome,
            Valor = p.Valor,
            Quantidade = p.Quantidade,
            ProdutoTipoId = p.ProdutoTipoId,
            ProdutoTipo = new ProdutoTipoViewModel
            {
                Id = p.ProdutoTipo.Id,
                Nome = p.ProdutoTipo.Nome,
            }
        }).ToList();

        return View(produtosViewModel);
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var produto = await _context.Produtos
            .Include(p => p.ProdutoTipo)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (produto == null)
        {
            return NotFound();
        }

        var produtoViewModel = new ProdutoViewModel
        {
            Id = produto.Id,
            Nome = produto.Nome,
            Valor = produto.Valor,
            Quantidade = produto.Quantidade,
            ProdutoTipoId = produto.ProdutoTipoId,
            ProdutoTipo = new ProdutoTipoViewModel
            {
                Id = produto.ProdutoTipo.Id,
                Nome = produto.ProdutoTipo.Nome,
            }
        };

        return View(produtoViewModel);
    }

    //GET/CREATE
    public IActionResult Create()
    {
        var produtoViewModel = new ProdutoViewModel();
        //var clientes = _context.Clientes.Include(c => c.Pessoa).OrderBy(x => x.Pessoa.Nome).ToList();
        var produtos = _context.ProdutoTipos.OrderBy(x => x.Nome).ToList();
        //ViewBag.Clientes = clientes;
        ViewBag.Produtos = produtos;
        return View(produtoViewModel);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ProdutoViewModel produtoViewModel)
    {
        if (ModelState.IsValid)
        {
            var produto = new Produto
            {
                Nome = produtoViewModel.Nome,
                Valor = produtoViewModel.Valor,
                Quantidade = produtoViewModel.Quantidade,
                ProdutoTipoId = produtoViewModel.ProdutoTipoId,
            };

            _context.Add(produto);
            await _context.SaveChangesAsync();
        }

        ViewBag.Produtos = _context.ProdutoTipos.OrderBy(x => x.Nome).ToList();
        return RedirectToAction(nameof(Index));
    }

    //GET/EDIT
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var produto = await _context.Produtos
            .Include(p => p.ProdutoTipo)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (produto == null)
        {
            return NotFound();
        }

        ViewBag.Produtos = _context.ProdutoTipos.OrderBy(x => x.Nome).ToList();

        var produtoViewModel = new ProdutoViewModel
        {
            Id = produto.Id,
            Nome = produto.Nome,
            Valor = produto.Valor,
            Quantidade = produto.Quantidade,
            ProdutoTipoId = produto.ProdutoTipoId,
        };

        return View(produtoViewModel);
    }

    //POST/EDIT
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int? id, ProdutoViewModel produtoViewModel)
    {
        if (id != produtoViewModel.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                var produto = await _context.Produtos
                    .Include(p => p.ProdutoTipo)
                    .FirstOrDefaultAsync(p => p.Id == id);

                if(produto == null)
                {
                    return NotFound();
                }

                produto.Nome = produtoViewModel.Nome;
                produto.Valor = produtoViewModel.Valor;
                produto.Quantidade = produtoViewModel.Quantidade;
                produto.ProdutoTipoId = produtoViewModel.ProdutoTipoId;

                _context.Update(produto);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

                if (!ProdutoExists(produtoViewModel.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        //ViewBag.Clientes = _context.Clientes.Include(c => c.Pessoa).OrderBy(x => x.Pessoa.Nome).ToList();
        ViewBag.Produtos = _context.ProdutoTipos.OrderBy(x => x.Nome).ToList();
        return RedirectToAction(nameof(Index));

    }

    //GET/DELETE
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var produto = await _context.Produtos
            .Include(p => p.ProdutoTipo)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (produto == null)
        {
            return NotFound();
        }

        var produtoViewModel = new ProdutoViewModel
        {
            Id = produto.Id,
            Nome = produto.Nome,
            Valor = produto.Valor,
            Quantidade = produto.Quantidade,
            ProdutoTipoId = produto.ProdutoTipoId,
            ProdutoTipo = new ProdutoTipoViewModel
            {
                Id = produto.ProdutoTipo.Id,
                Nome = produto.ProdutoTipo.Nome
            }
        };

        return View(produtoViewModel);
    }

    //POST/DELETE
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int? id)
    {
        var produto = await _context.Produtos.FindAsync(id);

        if (produto != null)
        {
            _context.Produtos.Remove(produto);
        }

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    private bool ProdutoExists(int? id)
    {
        return _context.Produtos.Any(p => p.Id == id);
    }
}

