﻿using CarCRM.Models;

namespace CarCRM.ViewModels
{
    public class FornecedorViewModel : PessoaViewModel
    {
        public int Id { get; set; }
        public string Documento { get; set; }
        public int FornecedorTipoId { get; set; }

        public FornecedorTipoViewModel FornecedorTipo { get; set; }
    }
}
